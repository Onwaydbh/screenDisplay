# -*- coding: utf-8 -*-
"""
--------------------------------------
Project Name: BigScreenDisplay
File Name: model.py
Author: Onway
Create Date: 2022/5/27
--------------------------------------
"""
from datetime import datetime, date, timedelta
import pandas as pd
import numpy as np
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.api import ExponentialSmoothing

import warnings
warnings.filterwarnings('ignore')

class predictModel:
	def model(self,data):
		year=str(datetime.now().year)
		startDate=year+"-"+data[0][0].split(".")[0]+"-"+data[0][0].split(".")[1]
		endDate=year+"-"+data[0][-1].split(".")[0]+"-"+data[0][-1].split(".")[1]
		date_index=pd.date_range(startDate,endDate)
		trainData=pd.DataFrame({'date':date_index,"value":data[1]})
		trainData.index=trainData['date']
		ts=trainData['value']
		model_fit=ExponentialSmoothing(ts,seasonal_periods=25,trend='mul',seasonal='mul').fit()
		startstart=str(date_index[-1]+timedelta(days=1)).split(" ")[0]
		endend=str(date_index[-1]+timedelta(days=7)).split(" ")[0]
		predicts=model_fit.predict(start=startstart,end=endend)
		# Date=pd.date_range(startstart,endend)
		predictDate=[]
		predictAdd=[]
		for i in date_index:
			predictDate.append(str(i).split(" ")[0][5:])
		for i in range(len(predicts)):
			predictDate.append(str(predicts.index[i]).split(" ")[0][5:])
			predictAdd.append(int(predicts[i]))
		predict={"predictDate":predictDate[len(predictDate)-67:],"predictAdd":predictAdd}
		return predict


	def predict(self,data):
		return self.model(data)


