# -*- coding: utf-8 -*-
"""
--------------------------------------
Project Name: BigScreenDisplay
File Name: dataCrawler.py
Author: Onway
Create Date: 2022/5/27
--------------------------------------
"""

import json

import pandas
import requests
from pymongo import MongoClient
import datetime

class crawlData:
	def __init__(self):
		self.worldUrl = 'https://api.inews.qq.com/newsqa/v1/automation/modules/list?modules=FAutoCountryConfirmAdd,WomWorld,WomAboard'
		self.historyurl = 'https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=chinaDayList,chinaDayAddList,nowConfirmStatis,provinceCompare'
		self.provinceurl = 'https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=statisGradeCityDetail,diseaseh5Shelf'
		self.client = MongoClient(
			"mongodb+srv://dbh:dbh04051204@cluster0.uspgg.mongodb.net/myFirstDatabase?retryWrites=true&w=majority")
		self.db = self.client.coronavirus

	def get_page_world_data(self):
		response = requests.get(self.worldUrl)
		page = response.content.decode()
		page_data = json.loads(page)
		worldCountry = page_data['data']['WomAboard']
		return worldCountry

	def save_MongoDB_world(self, worldCountry):
		collection = self.db.worldcountry
		for country in worldCountry:
			collection.update_one({'name':country['name']},{"$set":{'nowConfirm':country['nowConfirm'],'confirm': country['confirm'],'dead': country['dead']}})

	def get_page_history_data(self):
		response = requests.get(self.historyurl)
		page = response.content.decode()
		page_data = json.loads(page)
		daily_data = page_data['data']
		return daily_data

	def save_MongoDB_history(self, daily_data):
		collection = self.db.chinahistory
		coll=self.db.chinahistory
		updateTime="2022."+list(coll.find())[-1]['date']
		updateTime=str(datetime.datetime.strptime(updateTime,"%Y.%m.%d") + datetime.timedelta(days=1)).split(" ")[0]
		today=str(datetime.datetime.now()).split(" ")[0]
		daily_add=daily_data['chinaDayAddList']
		daily_data0=daily_data['chinaDayList']
		time_index=pandas.date_range(updateTime,today)
		length=len(daily_add)
		for i in range(len(time_index)-1,0,-1):
			day_data = {
				'date': daily_add[length - i]['date'],
				'confirmAdd': daily_add[length-i]['localConfirmadd'],
				'confirm':daily_data0[length-i]['localConfirm']
			}
			collection.insert_one(day_data)

	def get_page_province_data(self):
		response = requests.get(self.provinceurl)
		page = response.content.decode()
		page_data = json.loads(page)
		chinaProvince = page_data['data']['diseaseh5Shelf']['areaTree'][0]['children']
		chinaTotal = page_data['data']['diseaseh5Shelf']['chinaTotal']
		chinaProvince.append(chinaTotal)
		return chinaProvince

	def save_MongoDB_province(self, chinaProvince):
		collection1 = self.db.chinaprovince
		collection2 = self.db.chinaTotal
		time0=str(datetime.datetime.now()).split(".")[0]
		china_data = {
			'nowConfirm': chinaProvince[-1]['nowConfirm'],
			'confirm': chinaProvince[-1]['confirm'],
			'upgradetime':time0,
		}
		collection2.update_one({'name': '中国'},{"$set":china_data})
		for province in chinaProvince[:-1]:
			province_data = {
				"nowConfirm": province['total']['nowConfirm'],
				'confirm': province['total']['confirm'],
				'wzz': province['total']['wzz'],
				'dead': province['total']['dead'],
				'localAdd':province['today']['confirm']
			}
			collection1.update_one({'name': province['name']},{"$set":province_data})

	def run(self):
		worldData = self.get_page_world_data()
		self.save_MongoDB_world(worldData)
		historyData = self.get_page_history_data()
		self.save_MongoDB_history(historyData)
		provinceData = self.get_page_province_data()
		self.save_MongoDB_province(provinceData)
		print("数据更新完毕")
